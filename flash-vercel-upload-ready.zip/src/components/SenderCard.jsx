import React, { useState } from 'react';
import { sendTRC20 } from '../chains/tron';
import { sendERC20 } from '../chains/evm';
import { sendSolanaUSDT } from '../chains/solana';

const SenderCard = () => {
  const [network, setNetwork] = useState('TRON');
  const [token, setToken] = useState('USDT');
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [license, setLicense] = useState('');
  const [verified, setVerified] = useState(false);

  const verifyLicense = async () => {
    try {
      const res = await fetch('http://localhost:5000/verify-license', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: license })
      });

      const data = await res.json();
      if (data.success) {
        setVerified(true);
      } else {
        alert(data.message || 'License verification failed');
      }
    } catch (err) {
      alert('License server error: ' + err.message);
    }
  };

  const handleSend = async () => {
    try {
      if (network === 'TRON') {
        await sendTRC20(address, amount);
      } else if (network === 'Ethereum' || network === 'BSC') {
        await sendERC20(address, amount, network, token);
      } else if (network === 'Solana') {
        await sendSolanaUSDT(address, amount);
      }
      alert(`Sent ${amount} ${token} on ${network}`);
    } catch (e) {
      alert('Error: ' + e.message);
    }
  };

  if (!verified) {
    return (
      <div className="text-white p-6 border rounded-xl border-red-500 w-full max-w-xl text-center">
        <h1 className="text-xl font-bold mb-4">Enter License Key</h1>
        <input
          value={license}
          onChange={e => setLicense(e.target.value)}
          className="w-full mb-4 p-2 bg-black border border-red-400 rounded"
          placeholder="FLASH-XXXXX-XXXXX"
        />
        <button onClick={verifyLicense} className="w-full py-2 bg-red-500 hover:bg-red-600 rounded">
          VERIFY
        </button>
      </div>
    );
  }

  return (
    <div className="text-white p-6 border rounded-xl border-green-500 w-full max-w-xl">
      <h1 className="text-xl font-bold mb-4">Multi-Chain Token Sender</h1>

      <div className="grid grid-cols-2 gap-2 mb-4">
        <select onChange={e => setNetwork(e.target.value)} className="p-2 bg-black border border-green-400 rounded">
          <option>TRON</option>
          <option>Ethereum</option>
          <option>BSC</option>
          <option>Solana</option>
        </select>
        <select onChange={e => setToken(e.target.value)} className="p-2 bg-black border border-green-400 rounded">
          <option>USDT</option>
          <option>LINK</option>
        </select>
      </div>

      <input value={address} onChange={e => setAddress(e.target.value)} className="w-full mb-2 p-2 bg-black border border-green-500 rounded" placeholder="Recipient Address" />
      <input value={amount} onChange={e => setAmount(e.target.value)} className="w-full mb-4 p-2 bg-black border border-green-500 rounded" placeholder="Amount" />
      <button onClick={handleSend} className="w-full py-2 bg-green-600 hover:bg-green-700 rounded">SEND</button>
    </div>
  );
};

export default SenderCard;
