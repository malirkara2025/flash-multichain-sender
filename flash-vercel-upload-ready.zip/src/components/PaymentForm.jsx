import React, { useState } from 'react';

const PaymentForm = () => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [amount, setAmount] = useState('30');
  const [method, setMethod] = useState('Crypto');
  const [paymentId, setPaymentId] = useState('');
  const [proof, setProof] = useState('');

  const requestPayment = async () => {
    const res = await fetch('http://localhost:5000/payment-request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, amount, method })
    });
    const data = await res.json();
    if (data.success) {
      setPaymentId(data.id);
      setStep(2);
    } else {
      alert(data.message);
    }
  };

  const confirmPayment = async () => {
    const res = await fetch('http://localhost:5000/confirm-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: paymentId, proof })
    });
    const data = await res.json();
    if (data.success) {
      alert('Payment submitted successfully! Admin will verify soon.');
      setStep(3);
    } else {
      alert(data.message);
    }
  };

  return (
    <div className="text-white p-6 border border-blue-500 rounded-xl w-full max-w-xl">
      {step === 1 && (
        <>
          <h2 className="text-xl font-bold mb-4">Choose Payment Method</h2>
          <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Your Email" className="w-full p-2 mb-2 bg-black border border-blue-400 rounded" />
          <select onChange={e => setMethod(e.target.value)} className="w-full p-2 mb-2 bg-black border border-blue-400 rounded">
            <option>Crypto</option>
            <option>PayPal</option>
            <option>Wire Transfer</option>
          </select>
          <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" className="w-full p-2 mb-4 bg-black border border-blue-400 rounded" />
          <button onClick={requestPayment} className="w-full py-2 bg-blue-600 hover:bg-blue-700 rounded">Submit Payment Info</button>
        </>
      )}
      {step === 2 && (
        <>
          <h2 className="text-lg font-bold mb-2">Step 2: Submit Proof</h2>
          <p className="text-sm mb-2">Send your payment and paste the proof (TXID, PayPal ID, or receipt link):</p>
          <input value={proof} onChange={e => setProof(e.target.value)} className="w-full p-2 mb-4 bg-black border border-blue-400 rounded" placeholder="Enter proof..." />
          <button onClick={confirmPayment} className="w-full py-2 bg-green-600 hover:bg-green-700 rounded">Submit Proof</button>
        </>
      )}
      {step === 3 && (
        <div className="text-green-400 font-bold text-center">
          ✅ Thank you! Your request has been submitted.<br />
          License will be emailed after verification.
        </div>
      )}
    </div>
  );
};

export default PaymentForm;
